﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using Assingment_Mvc_project;

namespace Assingment_Mvc_project.Controllers
{
    public class Friend_TrishaController : Controller
    {
        private AdventureWorks2017Entities db = new AdventureWorks2017Entities();

        // GET: Friend_Trisha
        public ActionResult Index()
        {
            return View(db.Friend_Trisha.ToList());
        }

        // GET: Friend_Trisha/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Friend_Trisha friend_Trisha = db.Friend_Trisha.Find(id);
            if (friend_Trisha == null)
            {
                return HttpNotFound();
            }
            return View(friend_Trisha);
        }

        // GET: Friend_Trisha/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: Friend_Trisha/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "FriendId,FriendName,Place")] Friend_Trisha friend_Trisha)
        {
            if (ModelState.IsValid)
            {
                db.Friend_Trisha.Add(friend_Trisha);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(friend_Trisha);
        }

        // GET: Friend_Trisha/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Friend_Trisha friend_Trisha = db.Friend_Trisha.Find(id);
            if (friend_Trisha == null)
            {
                return HttpNotFound();
            }
            return View(friend_Trisha);
        }

        // POST: Friend_Trisha/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "FriendId,FriendName,Place")] Friend_Trisha friend_Trisha)
        {
            if (ModelState.IsValid)
            {
                db.Entry(friend_Trisha).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(friend_Trisha);
        }

        // GET: Friend_Trisha/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Friend_Trisha friend_Trisha = db.Friend_Trisha.Find(id);
            if (friend_Trisha == null)
            {
                return HttpNotFound();
            }
            return View(friend_Trisha);
        }

        // POST: Friend_Trisha/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            Friend_Trisha friend_Trisha = db.Friend_Trisha.Find(id);
            db.Friend_Trisha.Remove(friend_Trisha);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
